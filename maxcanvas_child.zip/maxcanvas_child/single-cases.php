<?php get_header();?>
	<h2>This is Single Page for CPT "Cases Studies"</h2>
<?php get_footer();?>
